import requests
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import networkx as nx
from lifelines import KaplanMeierFitter
from sklearn.preprocessing import LabelEncoder
from collections import defaultdict
import numpy as np  # Added numpy import for matrix operations
import community as community_louvain  # For community detection

# Base URL for cBioPortal API
BASE_URL = "https://www.cbioportal.org/api"

# Define the cancer study ID (Glioblastoma)
STUDY_ID = "gbm_tcga_pub2013"

# Function to fetch data from cBioPortal API
def fetch_data(endpoint, params=None):
    url = f"{BASE_URL}/{endpoint}"
    response = requests.get(url, params=params, headers={"Accept": "application/json"})
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Error fetching {endpoint}: {response.status_code} - {response.text}")
        return None

# Fetch available studies (just to verify)
studies = fetch_data("studies")
if studies:
    print("Available Studies Sample:")
    print(studies[:5])

# Fetch available sample lists to verify correct `SAMPLE_LIST_ID`
sample_lists = fetch_data(f"studies/{STUDY_ID}/sample-lists")
if sample_lists:
    print("\nAvailable Sample Lists:")
    for s in sample_lists:
        print(f" - {s['sampleListId']} ({s['description']})")

# Define the correct molecular profile and sample list
MUTATION_PROFILE_ID = f"{STUDY_ID}_mutations"  # Check if this exists
SAMPLE_LIST_ID = f"{STUDY_ID}_sequenced"  # Update based on the sample list output

# Fetch mutation data
mutation_data = fetch_data(
    f"molecular-profiles/{MUTATION_PROFILE_ID}/mutations",
    params={"sampleListId": SAMPLE_LIST_ID, "projection": "DETAILED"}
)

# Convert mutation data to DataFrame
if mutation_data:
    mutation_df = pd.DataFrame(mutation_data)
    print("\nMutation Data Sample:")
    print(mutation_df.head())
else:
    print("No mutation data found.")

# Extract gene mutations
mutations = mutation_df[['sampleId', 'gene']]
print(mutations['gene'].head())

# Clean up the 'gene' column if it's in a complex format (e.g., dictionary or other nested structures)
mutations.loc[:, 'gene'] = mutations['gene'].apply(lambda x: x['hugoGeneSymbol'] if isinstance(x, dict) else x)


# Create a mutation matrix: Rows = samples, Columns = genes, Values = 1 (if mutated), 0 (if not mutated)
genes = mutations['gene'].unique()
mutation_matrix = pd.DataFrame(0, index=mutations['sampleId'].unique(), columns=genes)

# Fill the mutation matrix: Set 1 where mutation occurred
for _, row in mutations.iterrows():
    mutation_matrix.loc[row['sampleId'], row['gene']] = 1

# Now, calculate the co-mutation matrix (How often genes mutate together)
co_mutation_matrix = np.dot(mutation_matrix.T, mutation_matrix)

# Convert co-mutation matrix to DataFrame for easier handling
co_mutation_df = pd.DataFrame(co_mutation_matrix, index=genes, columns=genes)

# Build a network graph using the co-mutation matrix
G = nx.Graph()

# Add nodes for each gene
for gene in genes:
    G.add_node(gene)

# Add edges between genes that co-mutate (edges with weight based on co-mutation frequency)
for i in range(len(genes)):
    for j in range(i+1, len(genes)):
        co_mutation_score = co_mutation_df.iloc[i, j]
        if co_mutation_score > 0:  # Only add edges where co-mutation occurs
            G.add_edge(genes[i], genes[j], weight=co_mutation_score)

# Plot the network graph (Gene network showing co-mutations)
plt.figure(figsize=(12, 12))
pos = nx.spring_layout(G, k=0.15, iterations=20)
nx.draw_networkx_nodes(G, pos, node_size=500)
nx.draw_networkx_edges(G, pos, width=1.0, alpha=0.5)
nx.draw_networkx_labels(G, pos, font_size=10)
plt.title("Gene Co-mutation Network")
plt.show()

# To detect clusters (communities) in the network
# We will use the Louvain method for community detection
partition = community_louvain.best_partition(G)

# Plot the network with communities
plt.figure(figsize=(12, 12))
pos = nx.spring_layout(G, k=0.15, iterations=20)
nx.draw_networkx_nodes(G, pos, node_size=500, node_color=list(partition.values()), cmap=plt.cm.rainbow)
nx.draw_networkx_edges(G, pos, width=1.0, alpha=0.5)
nx.draw_networkx_labels(G, pos, font_size=10)
plt.title("Gene Co-mutation Network with Communities")
plt.show()

'''

# Fetch clinical attributes (useful for mapping column names)
clinical_attributes = fetch_data(f"studies/{STUDY_ID}/clinical-attributes")
if clinical_attributes:
    print("\nClinical Attributes Sample:")
    for attr in clinical_attributes[:20]:  # Print only a few for readability
        print(f"{attr['clinicalAttributeId']}: {attr['displayName']} ({attr['datatype']})")

# Fetch clinical data
clinical_data = fetch_data(f"studies/{STUDY_ID}/clinical-data")

# Convert clinical data to DataFrame
if clinical_data:
    clinical_df = pd.DataFrame(clinical_data)
    print("\nClinical Data Sample:")
    print(clinical_df.head(20))
else:
    print("No clinical data found.")

'''






'''
# Base URL for cBioPortal API
BASE_URL = "https://www.cbioportal.org/api"

# Define the cancer study ID (Glioblastoma)
STUDY_ID = "gbm_tcga_pub2013"

# Function to fetch data from cBioPortal API
def fetch_data(endpoint, params=None):
    url = f"{BASE_URL}/{endpoint}"
    response = requests.get(url, params=params, headers={"Accept": "application/json"})
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Error fetching {endpoint}: {response.status_code}")
        return None

# Fetch available studies
studies = fetch_data("studies")
print("Available Studies Sample:")
print(studies[:5])

# Define the correct molecular profile and sample list from previous output
MUTATION_PROFILE_ID = f"{STUDY_ID}_mutations"  # Update this if needed
SAMPLE_LIST_ID = f"{STUDY_ID}_gbm_tcga_all"  # Update this if needed

# Fetch mutation data
mutation_response = requests.get(
    f"{BASE_URL}/molecular-profiles/{MUTATION_PROFILE_ID}/mutations",
    params={"sampleListId": SAMPLE_LIST_ID, "projection": "DETAILED"},
    headers={"Accept": "application/json"}
)

# Check response
if mutation_response.status_code == 200:
    mutation_data = mutation_response.json()
    mutation_df = pd.DataFrame(mutation_data)
    print("Mutation Data Sample:")
    print(mutation_df.head())
else:
    print(f"Error fetching mutations: {mutation_response.status_code}, {mutation_response.text}")


# CLinical attributes
clinical_attributes = fetch_data(f"studies/{STUDY_ID}/clinical-attributes")
print(clinical_attributes)
# Fetch clinical data
clinical_data = fetch_data(f"studies/{STUDY_ID}/clinical-data")

# Convert to DataFrame
if clinical_data:
    clinical_df = pd.DataFrame(clinical_data)
    print("Clinical Data Sample:")
    print(clinical_df.head())
'''